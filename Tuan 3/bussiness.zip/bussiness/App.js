import React from 'react';
import { View, StyleSheet,Image, Text, TouchableOpacity } from 'react-native';

const App = () => {
  return (
    <View style={styles.container}>
      <View style={[styles.box, styles.box1]}>
      <Image
          source={require('./Ellipse_8.png')}
          style={styles.image}
          resizeMode="contain"
          
        />
      </View>
      <View style={[styles.box, styles.box2]}>
         <Text style={styles.text}>GROW</Text>
         <Text style={styles.text}>YOUR BUSSINESS</Text>
      </View>
      <View style={[styles.box, styles.box3]}>
        <Text style={styles.text}>We will help you grow your bussiness using</Text>
        <Text style={styles.text}>online server</Text>
      </View>
      <View style={[styles.box, styles.box4]}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>LOGIN</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>SIGN UP</Text>
        </TouchableOpacity>

      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column', 
  },
  box: {
    flex: 1
  },
  box1: {
    backgroundColor: 'lightblue',
    alignItems: 'center',
    justifyContent: 'flex-end' 
  },
  image: {
    width: 100,  
    height: 100,
  },
  box2: {
    backgroundColor: 'lightblue', 
    alignItems: 'center',
    justifyContent: 'flex-end' 
  },
  box3: {
    backgroundColor: 'lightblue',
    alignItems: 'center',
    justifyContent: 'center'  
  },
  box4: {
    backgroundColor: 'lightblue', 
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-around'  
  },
  button: {
    backgroundColor: 'yellow',
    padding: 10,
    margin: 10,
    width: 150,
    alignItems: 'center',
    borderRadius: 5,
  },
  buttonText: {
    color: 'black',
    fontSize: 18,
  },
});

export default App;
