import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, CheckBox } from 'react-native';

const PasswordGenerator = () => {
  const [password, setPassword] = useState('');
  const [length, setLength] = useState('8');
  const [includeLower, setIncludeLower] = useState(true);
  const [includeUpper, setIncludeUpper] = useState(false);
  const [includeNumber, setIncludeNumber] = useState(true);
  const [includeSymbol, setIncludeSymbol] = useState(false);

  const generatePassword = () => {
    let characters = '';
    const lowerCase = 'abcdefghijklmnopqrstuvwxyz';
    const upperCase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    const symbols = '@#$';
    
    if (includeLower) characters += lowerCase;
    if (includeUpper) characters += upperCase;
    if (includeNumber) characters += numbers;
    if (includeSymbol) characters += symbols;

    let newPassword = '';
    const passLength = parseInt(length, 10);
    for (let i = 0; i < passLength; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      newPassword += characters[randomIndex];
    }
    setPassword(newPassword);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>PASSWORD GENERATOR</Text>
      
      <TextInput
        style={styles.passwordDisplay}
        value={password}
        editable={false}
        placeholder=""
        placeholderTextColor="white"
      />


      <View style={styles.row}>
        <Text style={styles.label}>Password length</Text>
        <TextInput
          style={styles.lengthInput}
          value={length}
          onChangeText={setLength}
          keyboardType="numeric"
        />
      </View>

      <View style={styles.checkboxContainer}>
        <CheckBox value={includeLower} onValueChange={setIncludeLower} />
        <Text style={styles.checkboxLabel}>Include lower case letters</Text>
      </View>

      <View style={styles.checkboxContainer}>
        <CheckBox value={includeUpper} onValueChange={setIncludeUpper} />
        <Text style={styles.checkboxLabel}>Include uppercase letters</Text>
      </View>

      <View style={styles.checkboxContainer}>
        <CheckBox value={includeNumber} onValueChange={setIncludeNumber} />
        <Text style={styles.checkboxLabel}>Include number</Text>
      </View>

      <View style={styles.checkboxContainer}>
        <CheckBox value={includeSymbol} onValueChange={setIncludeSymbol} />
        <Text style={styles.checkboxLabel}>Include special symbol</Text>
      </View>

      <TouchableOpacity style={styles.button} onPress={generatePassword}>
        <Text style={styles.buttonText}>GENERATE PASSWORD</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#2B2D42',
    padding: 20,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 20,
  },
  passwordDisplay: {
    height: 40,
    width: '80%',
    borderColor: '#000',
    borderWidth: 1,
    marginBottom: 20,
    textAlign: 'center',
    fontSize: 18,
    backgroundColor: '#000',
    color: '#fff',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    color: '#fff',
    marginRight: 10,
  },
  lengthInput: {
    height: 40,
    width: 120,
    borderColor: 'gray',
    borderWidth: 1,
    textAlign: 'center',
    fontSize: 18,
    backgroundColor: '#fff',
    color: '#000',
  },
  checkboxContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  checkboxLabel: {
    fontSize: 16,
    color: '#fff',
  },
  button: {
    backgroundColor: '#6C63FF',
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 5,
    marginTop: 20,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default PasswordGenerator;
