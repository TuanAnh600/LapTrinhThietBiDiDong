import * as React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';

function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={styles.productCard}>
        <Image
          source={require('./image/vs_blue.png')}
          style={styles.image}
        />
        <Text style={styles.title}>Điện Thoại Vsmart Joy 3 - Hàng chính hãng</Text>
        <View style={styles.ratingContainer}>
          <Ionicons name="star" size={16} color="gold" />
          <Ionicons name="star" size={16} color="gold" />
          <Ionicons name="star" size={16} color="gold" />
          <Ionicons name="star" size={16} color="gold" />
          <Ionicons name="star" size={16} color="gold" />
          <Text style={styles.reviewCount}>(Xem 828 đánh giá)</Text>
        </View>

        <View style={styles.priceContainer}>
          <Text style={styles.currentPrice}>1.790.000 đ</Text>
          <Text style={styles.oldPrice}>1.790.000 đ</Text>
        </View>

        <View style={styles.promoContainer}>
          <Text style={styles.promoText}>Ở ĐÂU RẺ HƠN HOÀN TIỀN</Text>
          <Ionicons name="help-circle-outline" size={16} color="gray" />
        </View>

        <TouchableOpacity
          style={styles.selectColorButton}
          onPress={() => navigation.navigate('Chọn màu')}
        >
          <Text style={styles.selectColorButtonText}>4 MÀU-CHỌN MÀU</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.buyButton}>
          <Text style={styles.buyButtonText}>CHỌN MUA</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function DetailsScreen({ navigation }) {
  const [selectedColor, setSelectedColor] = React.useState('blue');

  const handleButtonPress = (color) => {
    setSelectedColor(color);
  };

  let imageSource;
  switch (selectedColor) {
    case 'red':
      imageSource = require('./image/vs_red.png');
      break;
    case 'blue':
      imageSource = require('./image/vs_blue.png');
      break;
    case 'black':
      imageSource = require('./image/vs_black.png');
      break;
    case 'silver':
      imageSource = require('./image/vs_silver.png');
      break;
    default:
      imageSource = require('./image/vs_blue.png');
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Image source={imageSource} style={styles.selectedImage} />
        <View>
          <Text style={styles.title}>Điện Thoại Vsmart Joy 3 Hàng chính hãng</Text>
          <Text>Màu: {selectedColor}</Text>
          <Text>Cung cấp bởi Tiki Tradding</Text>
          <Text style={styles.currentPrice}>1.790.000 đ</Text>
        </View>
      </View>

      <Text style={styles.chooseColorText}>Chọn một màu bên dưới:</Text>

      <View style={styles.colorOptions}>
        <TouchableOpacity
          style={[styles.colorOption, { backgroundColor: '#ADD8E6' }]}
          onPress={() => handleButtonPress('silver')}
        />
        <TouchableOpacity
          style={[styles.colorOption, { backgroundColor: 'red' }]}
          onPress={() => handleButtonPress('red')}
        />
        <TouchableOpacity
          style={[styles.colorOption, { backgroundColor: 'black' }]}
          onPress={() => handleButtonPress('black')}
        />
        <TouchableOpacity
          style={[styles.colorOption, { backgroundColor: 'blue' }]}
          onPress={() => handleButtonPress('blue')}
        />
      </View>

      <TouchableOpacity style={styles.confirmButton} onPress={() => navigation.goBack()}>
        <Text style={styles.confirmButtonText}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
}

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Chọn màu" component={DetailsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f5f5f5',
  },
  productCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 10,
    width: 320,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  image: {
    width: 200,
    height: 250,
    marginBottom: 10,
  },
  selectedImage: {
    width: 80,
    height: 100,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  reviewCount: {
    marginLeft: 5,
    color: 'gray',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  currentPrice: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
    marginRight: 10,
  },
  oldPrice: {
    fontSize: 14,
    color: 'gray',
    textDecorationLine: 'line-through',
  },
  promoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  promoText: {
    color: 'green',
    marginRight: 5,
  },
  selectColorButton: {
    width: '100%',
    paddingVertical: 10,
    backgroundColor: 'white',
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
  },
  selectColorButtonText: {
    fontSize: 14,
    color: 'black',
  },
  buyButton: {
    width: '100%',
    paddingVertical: 15,
    backgroundColor: 'red',
    borderRadius: 5,
    alignItems: 'center',
  },
  buyButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  chooseColorText: {
    fontSize: 16,
    marginBottom: 10,
  },
  colorOptions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '80%',
    marginBottom: 20,
  },
  colorOption: {
    width: 50,
    height: 50,
    borderRadius: 5,
  },
  confirmButton: {
    width: '80%',
    paddingVertical: 15,
    backgroundColor: '#4A90E2',
    borderRadius: 5,
    alignItems: 'center',
  },
  confirmButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default App;
