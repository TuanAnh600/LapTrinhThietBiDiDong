import React from 'react';
import { View, StyleSheet, Image, Text, TouchableOpacity, FlatList,SafeAreaView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const DATA = [
  {
    id: '1',
    title: 'Pinarello',
    price: '$1800',
    image: require('./assets/bike.png'),
  },
  {
    id: '2',
    title: 'Pina Mountain',
    price: '$1700',
    image: require('./assets/bike1.png'),
  },
  {
    id: '3',
    title: 'Pina Bike',
    price: '$1500',
    image: require('./assets/bike2.png'),
  },
  {
    id: '4',
    title: 'Pinarello',
    price: '$1900',
    image: require('./assets/bike3.png'),
  },
  {
    id: '5',
    title: 'Pinarello',
    price: '$2700',
    image: require('./assets/bike4.png'),
  },
  {
    id: '6',
    title: 'Pinarello',
    price: '$1350',
    image: require('./assets/bike5.png'),
  },
];

function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <View style={[styles.box, styles.box1]}>
        <Text style={styles.text}>A premium store for</Text>
        <Text style={styles.text}>sporter and their stylish choice</Text>
      </View>
      <SafeAreaView style={[styles.box, styles.box2]}>
      <Image
          source={require('./assets/bike.png')}
          style={styles.image}
          resizeMode="contain"
        />
    </SafeAreaView> 
      <View style={[styles.box, styles.box3]}>
        <Text style={styles.text}>POWER BIKE</Text>
        <Text style={styles.text}>SHOP</Text>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Details')} >
        <Text style={styles.buttonText}>Get Started</Text>
      </TouchableOpacity>
      </View>

    </View>
  );
}

function DetailsScreen() {
  return (
    <View style={styles.productContainer}>
      <FlatList
        data={DATA}
        renderItem={({ item }) => (
          <View style={styles.productCard}>
            <Image source={item.image} style={styles.productImage} />
            <Text style={styles.productTitle}>{item.title}</Text>
            <Text style={styles.productPrice}>{item.price}</Text>
          </View>
        )}
        keyExtractor={item => item.id}
        numColumns={2}
        columnWrapperStyle={styles.row} 
      />
    </View>
  );
}

const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen options={{ headerShown: false }} name="Home" component={HomeScreen} />
        <Stack.Screen
          name="Details"
          component={DetailsScreen}
          options={{ title: 'The worlds Best Bike' }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  box: {
    flex: 1,
  },
  text: {
    textAlign: 'center',
    fontSize: 20,
    fontWeight: 'bold',
  },
  box1: {
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  box2: {
    backgroundColor: 'lightpink',
    alignItems: 'center',
    justifyContent: 'flex-end',
    width: '100%',
    borderRadius: 20,
  },
  box3: {
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'space-evenly',
  },
  button: {
    backgroundColor: 'red',
    padding: 10,
    margin: 10,
    width: '80%',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 30,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
  },
  productContainer: {
    flex: 1,
    padding: 10,
  },
  row: {
    justifyContent: 'space-between', 
  },
  productCard: {
    backgroundColor: 'lightyellow',
    padding: 10,
    borderRadius: 5,
    margin: 5,
    flex: 1,
    marginVertical: 5,
    alignItems: 'center',
  },
  productTitle: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  productPrice: {
    fontSize: 16,
    color: 'gray',
  },
  productImage: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
});

export default App;
