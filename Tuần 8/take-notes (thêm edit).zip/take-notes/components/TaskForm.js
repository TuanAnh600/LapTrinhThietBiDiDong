import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';
import axios from 'axios';

const TaskForm = ({ navigation, route }) => {
  const { fetchTasks, task } = route.params || {};  // Get task if in edit mode
  const [title, setTitle] = useState(task ? task.title : ''); // Set title if editing

  const saveTask = async () => {
    if (task) {
      // If task exists, update it
      try {
        await axios.put(`https://66fc9603c3a184a84d1766b3.mockapi.io/api/v1/task/${task.id}`, { title, completed: task.completed });
        fetchTasks();
        navigation.goBack();
      } catch (error) {
        console.error('Error updating task:', error);
      }
    } else {
      // If no task, create a new one
      try {
        await axios.post('https://66fc9603c3a184a84d1766b3.mockapi.io/api/v1/task', { title, completed: false });
        fetchTasks();
        navigation.goBack();
      } catch (error) {
        console.error('Error adding task:', error);
      }
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Task Title"
        value={title}
        onChangeText={setTitle}
      />
      <View style={styles.buttonContainer}>
        <Button title={task ? "Update Task" : "Add Task"} onPress={saveTask} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  buttonContainer: {
    width: '80%',
    marginVertical: 10,
  },
});

export default TaskForm;
