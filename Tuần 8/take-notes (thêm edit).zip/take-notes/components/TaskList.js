import React, { useEffect, useState } from 'react';
import { View, FlatList, Button, Text, StyleSheet, Alert } from 'react-native';
import axios from 'axios';

const TaskList = ({ navigation }) => {
  const [tasks, setTasks] = useState([]);

  const fetchTasks = async () => {
    try {
      const response = await axios.get('https://66fc9603c3a184a84d1766b3.mockapi.io/api/v1/task');
      setTasks(response.data);
    } catch (error) {
      Alert.alert('Error', 'There was an error fetching the tasks');
      console.error('Fetch error:', error);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const deleteTask = async (id) => {
    Alert.alert(
      'Confirm Deletion',
      'Are you sure you want to delete this task?',
      [
        {
          text: 'Cancel',
          onPress: () => console.log('Deletion cancelled'),
          style: 'cancel',
        },
        {
          text: 'Delete',
          onPress: async () => {
            try {
              await axios.delete(`https://66fc9603c3a184a84d1766b3.mockapi.io/api/v1/task/${id}`);
              Alert.alert('Success', 'Task deleted successfully');
              fetchTasks();
            } catch (error) {
              Alert.alert('Error', 'There was an error deleting the task');
              console.error('Delete error:', error);
            }
          },
        },
      ],
      { cancelable: false }
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={tasks}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Text style={styles.itemTitle}>{item.title}</Text>
            <Button title="Edit" onPress={() => navigation.navigate('TaskForm', { task: item, fetchTasks })} />
            <Button title="Delete" onPress={() => deleteTask(item.id)} />
          </View>
        )}
      />
      <Button title="Add Task" onPress={() => navigation.navigate('TaskForm', { fetchTasks })} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 2,
  },
  itemTitle: {
    flex: 1,
    textAlign: 'flex-start',
  },
});

export default TaskList;
