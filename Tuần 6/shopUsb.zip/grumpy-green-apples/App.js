import React from 'react';
import {
  SafeAreaView,
  View,
  TextInput,
  FlatList,
  StyleSheet,
  Text,
  StatusBar,
  Image,
  TouchableOpacity,
} from 'react-native';

const DATA = [
  {
    id: '1',
    title: 'Cáp chuyển từ Cổng USB sang PS2',
    price: '69.900 đ',
    image: require('./giacchuyen1.png'),
    rating: 4.5,
    reviews: 15,
    discount: '39%',
  },
  {
    id: '2',
    title: 'Cáp chuyển từ Cổng USB sang PS2',
    price: '69.900 đ',
    image: require('./daynguon1.png'),
    rating: 4.2,
    reviews: 15,
    discount: '39%',
  },
];


const ProductItem = ({ product }) => (
  <View style={styles.productContainer}>
    <Image source={product.image} style={styles.productImage} />
    <Text style={styles.productTitle}>{product.title}</Text>
    <Text style={styles.productPrice}>{product.price}</Text>
    <Text style={styles.productDiscount}>-{product.discount}</Text>
    <View style={styles.ratingContainer}>
      {/* Display star ratings */}
      {[...Array(5)].map((_, index) => (
        <Text key={index} style={styles.star}>
          {index < Math.floor(product.rating) ? '★' : '☆'}
        </Text>
      ))}
      <Text style={styles.reviewCount}>({product.reviews})</Text>
    </View>
  </View>
);

const Header = () => (
  <View style={styles.headerContainer}>
    <TouchableOpacity style={styles.backButton}>
      <Image source={require('./return.png')} style={styles.backIcon} />
    </TouchableOpacity>
    <TextInput style={styles.searchBar} placeholder="Dây cáp usb" />
    <TouchableOpacity style={styles.cartButton}>
      <Image source={require('./cart.png')} style={styles.cartIcon} />
    </TouchableOpacity>
    <TouchableOpacity style={styles.menuButton}>
      <Image source={require('./Group_2.png')} style={styles.menuIcon} />
    </TouchableOpacity>
  </View>
);

const App = () => {
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={({ item }) => <ProductItem product={item} />}
        keyExtractor={(item) => item.id}
        numColumns={2} 
        ListHeaderComponent={Header}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 10,
    paddingVertical: 20,
  },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    backgroundColor: '#007aff',
  },
  backButton: {
    paddingHorizontal: 10,
  },
  backIcon: {
    width: 24,
    height: 24,
  },
  searchBar: {
    flex: 1,
    height: 40,
    backgroundColor: 'white',
    borderRadius: 20,
    paddingHorizontal: 15,
  },
  cartButton: {
    paddingHorizontal: 10,
  },
  cartIcon: {
    width: 24,
    height: 24,
  },
  menuButton: {
    paddingHorizontal: 10,
  },
  menuIcon: {
    width: 5,  
    height: 10,
  },
  productContainer: {
    flex: 1,
    padding: 10,
    margin: 5,
    backgroundColor: '#fff',
    borderRadius: 5,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 2,
  },
  productImage: {
    width: '100%',
    height: 100,
    resizeMode: 'contain',
  },
  productTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    marginVertical: 5,
  },
  productPrice: {
    fontSize: 14,
    color: '#000',
  },
  productDiscount: {
    fontSize: 12,
    color: '#ff5c5c',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  star: {
    color: '#FFD700',
    fontSize: 14,
  },
  reviewCount: {
    marginLeft: 5,
    color: '#888',
  },
});

export default App;
