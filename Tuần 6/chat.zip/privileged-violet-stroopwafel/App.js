import React from 'react';
import {
  SafeAreaView,
  View,
  FlatList,
  StyleSheet,
  Text,
  StatusBar,
  Image,
  TouchableOpacity,
} from 'react-native';


const returnIcon = require('./return.png');
const shopIcon = require('./cart.png');

const DATA = [
  {
    id: '1',
    title: 'Ca nấu lẩu mì mini',
    shop: 'Shop Devang',
    image: require('./ca_nau_lau.png'),
  },
  {
    id: '2',
    title: '1KG Khô gà bơ tỏi',
    shop: 'Shop LTD Food',
    image: require('./ga_bo_toi.png'),
  },
  {
    id: '3',
    title: 'Xe cần cẩu đa năng',
    shop: 'Shop The gioi do choi',
    image: require('./xa_can_cau.png'),
  },
];

// Item component for the product
const Item = ({ obj }) => (
  <View style={styles.item}>
    <Image source={obj.image} style={styles.image} />
    <View style={styles.textContainer}>
      <Text style={styles.productName}>{obj.title}</Text>
      <Text style={styles.shopName}>{obj.shop}</Text>
    </View>
    <TouchableOpacity
      style={styles.chatButton}
      onPress={() => alert('Chat with shop')}>
      <Text style={styles.buttonText}>Chat</Text>
    </TouchableOpacity>
  </View>
);

// Header component with return and shop button
const Header = () => {
  const onPressReturnButton = () => {
    alert('Return button pressed!');
  };

  const onPressShopButton = () => {
    alert('Shop button pressed!');
  };

  return (
    <View style={styles.headerContainer}>
      {/* Return button with image on the left */}
      <TouchableOpacity style={styles.returnButton} onPress={onPressReturnButton}>
        <Image source={returnIcon} style={styles.returnImage} />
      </TouchableOpacity>

      {/* Centered Title */}
      <Text style={styles.headerText}>Chat</Text>

      {/* Shop button with image on the right */}
      <TouchableOpacity style={styles.headerButton} onPress={onPressShopButton}>
        <Image source={shopIcon} style={styles.shopImage} />
      </TouchableOpacity>
    </View>
  );
};

// Main App component
const App = () => {
  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={({ item }) => <Item obj={item} />}
        keyExtractor={(item) => item.id}
        ListHeaderComponent={Header} // Adding header to the FlatList
      />
    </SafeAreaView>
  );
};

// Styling
const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: StatusBar.currentHeight || 0,
    paddingHorizontal: 10,
    paddingVertical: 20,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 2,
  },
  image: {
    width: 60,
    height: 60,
    marginRight: 10,
  },
  productName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  shopName: {
    fontSize: 14,
    color: 'gray',
  },
  headerContainer: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#007aff',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  headerText: {
    fontSize: 20,
    color: '#fff',
    fontWeight: 'bold',
    textAlign: 'center',
    flex: 1, // This makes sure the title remains centered
  },
  returnButton: {
    position: 'absolute', // To place it on the leftmost side
    left: 10, // Align to the left
  },
  returnImage: {
    width: 30, // Set the width of your return icon
    height: 30, // Set the height of your return icon
  },
  headerButton: {
    position: 'absolute', // To place it on the rightmost side
    right: 10, // Align to the right
  },
  shopImage: {
    width: 30, // Set the width of your shop icon
    height: 30, // Set the height of your shop icon
  },
  chatButton: {
    backgroundColor: '#ff5c5c',
    paddingHorizontal: 15,
    paddingVertical: 5,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default App;
