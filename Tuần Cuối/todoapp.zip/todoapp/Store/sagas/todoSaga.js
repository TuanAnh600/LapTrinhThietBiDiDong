// src/store/sagas/todoSaga.js
import { takeEvery, put } from 'redux-saga/effects';
import { ADD_TODO_REQUEST, REMOVE_TODO_REQUEST } from '../actions/todoAction.js';

function* addTodoSaga(action) {
  yield put({ type: 'ADD_TODO', payload: action.payload });
}

function* removeTodoSaga(action) {
  yield put({ type: 'REMOVE_TODO', payload: action.payload });
}

export function* watchTodo() {
  yield takeEvery(ADD_TODO_REQUEST, addTodoSaga);
  yield takeEvery(REMOVE_TODO_REQUEST, removeTodoSaga);
}
