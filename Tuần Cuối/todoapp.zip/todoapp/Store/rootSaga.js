// src/store/rootSaga.js
import { all } from 'redux-saga/effects';
import { watchTodo } from './sagas/todoSaga';

export default function* rootSaga() {
  yield all([watchTodo()]);
}
