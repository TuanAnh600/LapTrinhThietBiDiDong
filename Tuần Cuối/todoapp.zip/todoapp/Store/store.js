// src/store/store.js
import { createStore, applyMiddleware } from 'redux';
import createSagaMiddleware from 'redux-saga';
import rootReducer from './rootReducer';
import rootSaga from './rootSaga';

// Tạo middleware cho saga
const sagaMiddleware = createSagaMiddleware();

// Tạo một store Redux
const store = createStore(
  rootReducer,
  applyMiddleware(sagaMiddleware)
);

// Chạy saga
sagaMiddleware.run(rootSaga);

export default store;
