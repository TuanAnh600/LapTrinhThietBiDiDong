// src/store/actions/todoActions.js
export const ADD_TODO_REQUEST = 'ADD_TODO_REQUEST';
export const ADD_TODO = 'ADD_TODO';
export const REMOVE_TODO_REQUEST = 'REMOVE_TODO_REQUEST';
export const REMOVE_TODO = 'REMOVE_TODO';
