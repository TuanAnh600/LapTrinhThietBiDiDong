// src/components/Todo.js
import React, { useState } from 'react';
import { View, Text, Button, TextInput, FlatList, StyleSheet } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { ADD_TODO_REQUEST, REMOVE_TODO_REQUEST } from '../Store/actions/todoAction';

const Todo = () => {
  const [todoText, setTodoText] = useState('');
  const dispatch = useDispatch();
  const todos = useSelector(state => state.todos.todos);

  const addTodo = () => {
    const newTodo = {
      id: Date.now(),
      text: todoText,
    };
    dispatch({ type: ADD_TODO_REQUEST, payload: newTodo });
    setTodoText('');
  };

  const removeTodo = (id) => {
    dispatch({ type: REMOVE_TODO_REQUEST, payload: { id } });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Todo List</Text> 
      <TextInput
        value={todoText}
        onChangeText={setTodoText}
        placeholder="Nhập todo..."
        style={styles.input} 
      />
      <Button title="Thêm Todo" onPress={addTodo} />
      <FlatList
        data={todos}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.itemContainer}>
            <Text style={styles.itemTitle}>{item.text}</Text>
            <Button title="Xóa" onPress={() => removeTodo(item.id)} />
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center', 
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fff',
    borderRadius: 5,
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 2,
  },
  itemTitle: {
    flex: 1,
    textAlign: 'flex-start',
  },
});

export default Todo;
