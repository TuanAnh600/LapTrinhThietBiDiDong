import React, { useState } from 'react';
import { View, TextInput, Button, StyleSheet } from 'react-native';
import axios from 'axios';

const TaskForm = ({ navigation, route }) => {
  const { fetchTasks } = route.params;
  const [title, setTitle] = useState('');

  const addTask = async () => {
    await axios.post('https://66fc9603c3a184a84d1766b3.mockapi.io/api/v1/task', { title, completed: false });
    fetchTasks();
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Task Title"
        value={title}
        onChangeText={setTitle}
      />
      <View style={styles.buttonContainer}>
        <Button title="Add Task" onPress={addTask} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  buttonContainer: {
    width: '80%', 
    marginVertical: 10,
  }
  });
export default TaskForm;
